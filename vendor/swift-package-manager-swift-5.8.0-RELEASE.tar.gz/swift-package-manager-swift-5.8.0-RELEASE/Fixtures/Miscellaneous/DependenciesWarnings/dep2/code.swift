struct Dep2 {
  var deprecated: Deprecated2
}

@available(*, deprecated)
struct Deprecated2 {
}
