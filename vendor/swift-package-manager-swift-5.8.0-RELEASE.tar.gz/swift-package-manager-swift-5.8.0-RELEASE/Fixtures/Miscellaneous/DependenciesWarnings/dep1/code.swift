struct Dep1 {
  var deprecated: Deprecated1
}

@available(*, deprecated)
struct Deprecated1 {
}
