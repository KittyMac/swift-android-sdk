import XCTest

// TODO: - Can imports be made less ugly? (SR‐10839)
//@testable import πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄
@testable import π_µ_____x__________
// (These characters all work for identifiers. See below.)

final class πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄Tests: XCTestCase {
    
    func testπשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄() {
        XCTAssertEqual(πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄().πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄, "Hello, World!")
    }
}
