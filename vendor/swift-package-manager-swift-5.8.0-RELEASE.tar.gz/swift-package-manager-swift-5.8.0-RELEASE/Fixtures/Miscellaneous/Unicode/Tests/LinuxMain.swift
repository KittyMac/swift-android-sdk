import XCTest

import π_µ_____x__________Tests

var tests = [XCTestCaseEntry]()
tests += π_µ_____x__________Tests.__allTests()

XCTMain(tests)
