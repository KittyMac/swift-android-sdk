public struct πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄ {
    public init() {}
    public var πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄ = "Hello, World!"
}
