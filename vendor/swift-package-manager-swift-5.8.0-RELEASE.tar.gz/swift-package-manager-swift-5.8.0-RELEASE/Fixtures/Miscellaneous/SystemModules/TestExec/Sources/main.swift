import CFake

print("Hello, \(GetFakeString())!")
