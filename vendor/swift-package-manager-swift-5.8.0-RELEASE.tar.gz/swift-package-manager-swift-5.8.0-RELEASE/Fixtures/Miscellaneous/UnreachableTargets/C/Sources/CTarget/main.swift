print("CTarget")
