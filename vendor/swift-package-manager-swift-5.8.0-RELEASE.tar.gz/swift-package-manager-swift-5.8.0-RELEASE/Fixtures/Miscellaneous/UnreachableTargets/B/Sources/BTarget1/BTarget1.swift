public struct BTarget1 {
	public init() {}
}
