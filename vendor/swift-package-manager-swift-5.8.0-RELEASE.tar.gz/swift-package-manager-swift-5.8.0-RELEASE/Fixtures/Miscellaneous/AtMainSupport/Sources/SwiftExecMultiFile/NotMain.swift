@main
struct MyProgram {
    static func main() {
        print("Hello, Swift.")
    }
}
