import B
public func bar(x: Int) -> Int {
    return 11 + foo(x: x)
}
