public func GetGeneratedString() -> String {
    return "Generated string: \(generated)"
}
