public struct Library {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
