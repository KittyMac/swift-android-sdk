print("Generated string Foo: '\(foo)'")
