public struct MissingPlugin {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
