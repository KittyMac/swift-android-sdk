print("Generated string Foo: '\(PREFIX_foo)'")
