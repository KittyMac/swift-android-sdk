public func MyLibraryStruct() -> String {
    return "This is \(foo)"
}
