import RemoteToolHelperLibrary

print("A message from the \(RemoteToolHelperLibraryFunction()) tool.")
