public func RemoteToolHelperLibraryFunction() -> String {
    return "remote"
}
