public func Foo() -> String {
    return "Foo"
}
