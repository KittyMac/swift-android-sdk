import LocalToolHelperLibrary

print("A message from the implied \(LocalToolHelperFunction()) tool.")
