public func LocalToolHelperFunction() -> String {
    return "local"
}
