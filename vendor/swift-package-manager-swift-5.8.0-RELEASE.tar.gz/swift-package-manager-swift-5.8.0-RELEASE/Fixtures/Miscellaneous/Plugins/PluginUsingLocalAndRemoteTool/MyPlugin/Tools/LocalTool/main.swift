import LocalToolHelperLibrary

print("A message from the \(LocalToolHelperFunction()) tool.")
