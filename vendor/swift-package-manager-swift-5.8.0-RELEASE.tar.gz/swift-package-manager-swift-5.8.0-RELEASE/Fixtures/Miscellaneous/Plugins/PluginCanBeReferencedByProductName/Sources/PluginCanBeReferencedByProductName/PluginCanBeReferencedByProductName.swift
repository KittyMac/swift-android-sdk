public struct PluginCanBeReferencedByProductName {
    public private(set) var text = stringConstant

    public init() {
    }
}
