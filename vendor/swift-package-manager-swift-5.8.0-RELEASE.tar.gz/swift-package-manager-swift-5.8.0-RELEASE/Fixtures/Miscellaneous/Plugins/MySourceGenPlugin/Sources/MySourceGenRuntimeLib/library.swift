public func GetLibraryName() -> String {
    return "MySourceGenRuntimeLib"
}
