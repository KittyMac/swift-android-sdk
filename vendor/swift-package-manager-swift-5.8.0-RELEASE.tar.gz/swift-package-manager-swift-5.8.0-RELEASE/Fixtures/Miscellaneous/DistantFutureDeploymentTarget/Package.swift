// swift-tools-version:4.2
import PackageDescription

let package = Package(
    name: "DistantFutureDeploymentTarget",
    targets: [
        .target(name: "DistantFutureDeploymentTarget", path: "Sources"),
    ]
)
