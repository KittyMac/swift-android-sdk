public func GetGreeting1() -> String {
    return "Hello, world"
}

print("\(GetGreeting1())!")
