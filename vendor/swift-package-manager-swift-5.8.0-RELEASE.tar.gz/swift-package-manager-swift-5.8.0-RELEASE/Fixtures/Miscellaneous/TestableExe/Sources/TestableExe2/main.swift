public func GetGreeting2() -> String {
    return "Hello, planet"
}

print("\(GetGreeting2())!")
