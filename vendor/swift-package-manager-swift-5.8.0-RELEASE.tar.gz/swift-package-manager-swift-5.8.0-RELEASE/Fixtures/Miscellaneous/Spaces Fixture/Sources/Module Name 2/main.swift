import Module_Name_1

public class Foo {
    var bar: Int = 0
}
