public class Foo {
    var bar: Int = 0
}
