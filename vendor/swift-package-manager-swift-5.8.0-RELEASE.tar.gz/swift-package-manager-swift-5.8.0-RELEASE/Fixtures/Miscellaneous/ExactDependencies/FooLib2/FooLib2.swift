public class FooLib2 {
    public var foo: Int
    
    public init() {
        foo = 0
    }
}
