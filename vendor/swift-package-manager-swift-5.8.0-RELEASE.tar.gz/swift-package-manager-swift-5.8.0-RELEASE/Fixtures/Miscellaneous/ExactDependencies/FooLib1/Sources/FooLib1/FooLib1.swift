public class FooLib1 {
    public var foo: Int
    
    public init() {
        foo = 0
    }
}
