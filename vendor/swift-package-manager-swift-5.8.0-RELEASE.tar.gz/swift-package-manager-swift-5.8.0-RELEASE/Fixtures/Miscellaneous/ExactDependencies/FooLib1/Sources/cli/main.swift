import FooLib1

print(FooLib1())
