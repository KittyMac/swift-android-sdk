// swift-tools-version:4.2

import PackageDescription

let package = Package(
    name: "CompileFails",
    targets: [
        .target(name: "CompileFails", path: "./"),
    ]
)
