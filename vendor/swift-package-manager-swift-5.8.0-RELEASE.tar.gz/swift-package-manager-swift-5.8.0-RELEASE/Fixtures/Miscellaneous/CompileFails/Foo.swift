class Foo {
    var bar: Int = 0
    
    compile_failure
}
