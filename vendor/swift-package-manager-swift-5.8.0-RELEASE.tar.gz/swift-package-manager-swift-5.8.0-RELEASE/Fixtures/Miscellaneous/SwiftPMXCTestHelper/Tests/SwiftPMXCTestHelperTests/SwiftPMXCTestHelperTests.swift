import XCTest
@testable import SwiftPMXCTestHelper

class SwiftPMXCTestHelperTests1: XCTestCase {

    func testExample1() {
    }

    func test_Example2() {
    }

    func testExample3(arg: String) {
    }

    func nontest() {
    }
}
