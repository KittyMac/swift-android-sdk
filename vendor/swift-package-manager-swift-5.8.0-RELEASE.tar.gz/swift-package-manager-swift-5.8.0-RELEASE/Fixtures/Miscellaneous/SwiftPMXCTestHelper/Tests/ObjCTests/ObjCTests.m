@import XCTest;

@interface ObjCTests: XCTestCase
@end

@implementation ObjCTests

- (void)testThisThing {
}

- (void)test_example {
}

- (void)nonTest {
}

@end
