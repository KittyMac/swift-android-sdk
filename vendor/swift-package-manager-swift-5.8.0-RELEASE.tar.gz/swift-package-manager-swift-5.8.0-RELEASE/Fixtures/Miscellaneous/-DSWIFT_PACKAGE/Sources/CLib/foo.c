#include "CLib.h"

void foo(void) { }
