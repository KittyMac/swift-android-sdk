import Foo
import Bar

public func main() {
}
