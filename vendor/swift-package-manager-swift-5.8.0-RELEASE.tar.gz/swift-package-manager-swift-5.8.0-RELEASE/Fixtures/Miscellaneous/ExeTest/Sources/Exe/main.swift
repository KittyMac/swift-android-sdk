public func GetGreeting() -> String {
    return "Hello"
}

print("\(GetGreeting()), world!")
