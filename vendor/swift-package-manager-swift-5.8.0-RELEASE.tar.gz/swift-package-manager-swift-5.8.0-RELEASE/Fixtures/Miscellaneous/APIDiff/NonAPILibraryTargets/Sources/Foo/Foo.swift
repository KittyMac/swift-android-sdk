public struct Foo {
    func doThing() {}
}
