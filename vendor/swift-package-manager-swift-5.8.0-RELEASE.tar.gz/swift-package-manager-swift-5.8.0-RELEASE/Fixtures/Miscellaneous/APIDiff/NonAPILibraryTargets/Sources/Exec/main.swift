import Qux

print("Hello, world!")
