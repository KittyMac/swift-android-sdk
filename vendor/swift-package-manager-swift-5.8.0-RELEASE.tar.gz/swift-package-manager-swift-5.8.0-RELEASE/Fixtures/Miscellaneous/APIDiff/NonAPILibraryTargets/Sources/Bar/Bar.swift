import Baz

public func bar() -> Int {
    42
}
