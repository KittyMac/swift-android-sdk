public enum Baz {
    case a, c
}
