import Foo

public func bar() -> Int {
    foo()
    return 42
}
