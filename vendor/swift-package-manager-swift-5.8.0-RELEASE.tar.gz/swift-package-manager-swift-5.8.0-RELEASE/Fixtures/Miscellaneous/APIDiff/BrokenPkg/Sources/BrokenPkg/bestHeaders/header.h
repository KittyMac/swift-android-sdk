#ifndef FLAG
#error "fail"
#endif
