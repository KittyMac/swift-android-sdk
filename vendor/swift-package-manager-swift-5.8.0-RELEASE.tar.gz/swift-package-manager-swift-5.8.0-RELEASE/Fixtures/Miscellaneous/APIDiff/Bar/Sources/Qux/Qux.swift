public class Qux<T> { public let x = 1 }
