public func bar() -> Int {
    42
}
