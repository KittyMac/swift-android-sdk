struct UnicodeDependency_UnicodeDependency_πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄ {
    var text = "Hello, World!"
}
