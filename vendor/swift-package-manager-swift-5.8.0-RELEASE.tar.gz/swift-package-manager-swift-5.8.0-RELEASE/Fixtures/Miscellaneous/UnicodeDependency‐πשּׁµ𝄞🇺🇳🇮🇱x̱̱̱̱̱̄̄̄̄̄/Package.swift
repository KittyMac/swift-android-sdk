// swift-tools-version:5.1

import PackageDescription

let package = Package(
    name: "UnicodeDependency‐πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄",
    products: [
        .library(
            name: "UnicodeDependency‐πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄",
            targets: ["UnicodeDependency‐πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄"]),
    ],
    targets: [
        .target(
            name: "UnicodeDependency‐πשּׁµ𝄞🇺🇳🇮🇱x̱̱̱̱̱̄̄̄̄̄",
            dependencies: []),
    ]
)
