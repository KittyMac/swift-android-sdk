import B_C

func ab() {
    bc()
}
