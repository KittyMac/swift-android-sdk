import dep1

print(foo)
