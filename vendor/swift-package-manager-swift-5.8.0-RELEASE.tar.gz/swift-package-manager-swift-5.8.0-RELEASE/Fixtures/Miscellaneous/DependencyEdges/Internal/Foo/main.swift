import Bar

print(bar)
