import CSystemModule

print("\(foo())")
