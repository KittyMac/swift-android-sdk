#include <SystemModule.h>
#include <stdio.h>

int main() {
    printf("%d", foo());
    return 0;
}
