import XCTest
@testable import Simple

class SimpleTests: XCTestCase {

    func testExample1() {
    }

    func test_Example2() {
    }

    func testThrowing() throws {
    }

    func testWithArgs(arg: String) {
    }

    func nontest() {
    }
}
