import XCTest

class Tests1: XCTestCase {
    func test11() {
      print("->Module2::Tests1::test11")
    }

    func test12() {
      print("->Module2::Tests1::test12")
    }

    func test13() {
      print("->Module2::Tests1::test13")
    }
}
