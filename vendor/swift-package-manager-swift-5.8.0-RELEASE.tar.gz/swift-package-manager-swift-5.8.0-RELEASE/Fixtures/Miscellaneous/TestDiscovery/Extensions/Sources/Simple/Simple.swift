struct Simple {

}
