import XCTest
@testable import Simple

extension SimpleTests1 {
    func testExample1_a() {
    }
}

extension SimpleTests2 {
    func testExample2_a() {
    }
}
