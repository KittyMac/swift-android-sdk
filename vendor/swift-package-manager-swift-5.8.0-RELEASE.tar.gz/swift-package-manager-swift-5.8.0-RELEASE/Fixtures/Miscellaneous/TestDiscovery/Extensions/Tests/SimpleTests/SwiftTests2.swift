import XCTest
@testable import Simple

class SimpleTests2: XCTestCase {
    func testExample2() {
    }
}
