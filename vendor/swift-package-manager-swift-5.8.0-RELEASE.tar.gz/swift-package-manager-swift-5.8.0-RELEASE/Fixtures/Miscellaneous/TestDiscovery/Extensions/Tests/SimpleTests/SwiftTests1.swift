import XCTest
@testable import Simple

class SimpleTests1: XCTestCase {
    func testExample1() {
    }
}
