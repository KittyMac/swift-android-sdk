import XCTest
@testable import Simple

class SimpleTests4: XCTestCase {
    func testExample() {
    }

    func testExample1() {
    }

    func testExample2() {
    }
}
