struct hello_world {
    var text = "Hello, World!"
}
