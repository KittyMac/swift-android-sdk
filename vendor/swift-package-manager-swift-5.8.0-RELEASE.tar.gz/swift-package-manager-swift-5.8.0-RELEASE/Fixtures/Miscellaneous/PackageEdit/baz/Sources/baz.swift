struct baz {

    var text = "Hello, World!"
}
