import bar
print(bar.theValue)
