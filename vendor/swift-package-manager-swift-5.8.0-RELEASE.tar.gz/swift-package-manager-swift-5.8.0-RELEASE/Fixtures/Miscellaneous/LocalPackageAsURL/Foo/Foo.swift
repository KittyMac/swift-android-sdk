public func foo() {
	{}()
}
