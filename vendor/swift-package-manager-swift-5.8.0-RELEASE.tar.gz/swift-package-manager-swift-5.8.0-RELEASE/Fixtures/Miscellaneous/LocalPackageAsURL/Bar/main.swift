import Foo

foo()
print("here")
