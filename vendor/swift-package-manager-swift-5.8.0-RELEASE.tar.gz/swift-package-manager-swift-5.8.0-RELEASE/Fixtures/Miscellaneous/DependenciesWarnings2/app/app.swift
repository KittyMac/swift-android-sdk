import dep1
import dep2

@main
struct App {
  public static func main() {
    print("hello, world!")
  }
}
