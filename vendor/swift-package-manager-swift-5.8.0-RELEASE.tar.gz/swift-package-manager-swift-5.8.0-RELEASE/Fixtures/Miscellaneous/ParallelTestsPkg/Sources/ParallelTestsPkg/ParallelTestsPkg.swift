struct ParallelTests {

    var text = "Hello, World!"
    var bool = false
}
