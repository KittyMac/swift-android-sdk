
import CHeaderInclude

enum Answer {
    var value: Int { Int(getAnswer()) }
}
