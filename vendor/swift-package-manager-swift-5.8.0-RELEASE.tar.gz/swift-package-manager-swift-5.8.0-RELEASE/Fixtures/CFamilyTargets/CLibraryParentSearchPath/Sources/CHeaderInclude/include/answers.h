
#ifndef answers_h
#define answers_h

extern int getAnswer(void);

#endif /* answers_h */
