
#include "answers.h"
#include "Constants.h"

int getAnswer(void) {
    return kTheAnswer;
}
