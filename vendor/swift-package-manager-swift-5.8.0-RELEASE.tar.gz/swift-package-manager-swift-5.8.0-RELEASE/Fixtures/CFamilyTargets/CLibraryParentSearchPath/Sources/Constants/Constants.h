
#ifndef Constants_h
#define Constants_h

static const int kTheAnswer = 42;

#endif /* Constants_h */
