// swift-tools-version:4.2
import PackageDescription

let package = Package(
    name: "CLibrarySources",
    targets: [
        .target(name: "CLibrarySources", path: "Sources"),
    ]
)
