import Foo
import Bar

let _ = foo()
let _ = bar()
