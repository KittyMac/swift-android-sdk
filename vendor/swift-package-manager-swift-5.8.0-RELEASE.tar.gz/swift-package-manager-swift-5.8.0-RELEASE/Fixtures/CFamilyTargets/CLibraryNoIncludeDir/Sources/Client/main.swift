import Cfactorial

print(factorial(5))
print("Hello, world!")
