#ifndef factorial_h
#define factorial_h

#include <stdio.h>

long factorial(int n);

#endif /* factorial_h */
