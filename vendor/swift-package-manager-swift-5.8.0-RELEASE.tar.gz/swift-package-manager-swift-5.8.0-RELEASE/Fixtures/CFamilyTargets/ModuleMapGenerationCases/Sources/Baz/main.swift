import UmbrellaDirectoryInclude
import FlatInclude
import UmbrellaHeader
import UmbrellaHeaderFlat

let _ = foo()
let _ = bar()
let _ = jaz()
let _ = umbrellaHeaderFlat()
