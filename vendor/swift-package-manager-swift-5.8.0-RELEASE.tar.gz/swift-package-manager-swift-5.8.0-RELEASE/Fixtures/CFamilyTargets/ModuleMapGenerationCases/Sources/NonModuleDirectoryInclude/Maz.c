#include "NonModuleDirectoryInclude/Maz.h"

int maz() {
    int a = 6;
    int b = a;
    a = b;
    return a;
}
