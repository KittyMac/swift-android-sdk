int jaz();
