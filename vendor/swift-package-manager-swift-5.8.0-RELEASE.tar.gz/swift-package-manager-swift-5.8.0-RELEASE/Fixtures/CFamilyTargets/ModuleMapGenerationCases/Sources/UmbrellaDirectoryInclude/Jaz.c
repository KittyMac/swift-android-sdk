#include "Paz.h"

int jaz() {
    int a = 6;
    int b = a;
    a = b;
    return a;
}
