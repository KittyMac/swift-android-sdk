
int noDir() {
    int a = 6;
    int b = a;
    a = b;
    return a;
}
