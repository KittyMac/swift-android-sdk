#include "Foo.h"
#include<stdio.h>

int main() {
    printf("%d", foo(5));
    return 0;
}
