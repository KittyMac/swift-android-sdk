import SeaLib

let a = foo(5)
print("a = \(a)")

