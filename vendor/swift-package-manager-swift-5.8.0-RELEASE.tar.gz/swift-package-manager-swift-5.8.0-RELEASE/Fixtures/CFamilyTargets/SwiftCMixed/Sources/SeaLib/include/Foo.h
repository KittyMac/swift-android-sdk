int foo(int a);
