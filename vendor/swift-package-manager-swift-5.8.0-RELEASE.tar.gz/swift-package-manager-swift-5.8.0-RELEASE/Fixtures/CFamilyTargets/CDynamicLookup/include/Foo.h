void bar();
int foo();
