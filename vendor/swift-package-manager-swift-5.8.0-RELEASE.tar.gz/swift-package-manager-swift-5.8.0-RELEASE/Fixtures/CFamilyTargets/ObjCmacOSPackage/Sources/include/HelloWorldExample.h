#import <Foundation/Foundation.h>

@interface HelloWorld : NSObject

- (NSString *)hello:(NSString *)name;

@end
