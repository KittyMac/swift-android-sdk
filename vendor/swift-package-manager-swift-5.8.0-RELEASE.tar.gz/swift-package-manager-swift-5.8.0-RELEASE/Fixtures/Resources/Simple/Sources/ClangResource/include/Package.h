#import <Foundation/Foundation.h>

@interface Package : NSObject

+ (NSBundle *)resourceBundle;

@end
