#import <Foundation/Foundation.h>

#import "Foo.h"

@implementation Foo
@end
