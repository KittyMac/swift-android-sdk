#ifndef foo_h
#define foo_h

#include <stdio.h>

#endif /* foo_h */
