@frozen
public enum FooUtils { }

extension FooUtils {
  public static let foo: String = "Hello, World!"
}
