// swift-tools-version:5.3
import PackageDescription

let package = Package(
    name: "Localized",
    defaultLocalization: "es",
    targets: [
        .target(name: "exe"),
    ]
)
