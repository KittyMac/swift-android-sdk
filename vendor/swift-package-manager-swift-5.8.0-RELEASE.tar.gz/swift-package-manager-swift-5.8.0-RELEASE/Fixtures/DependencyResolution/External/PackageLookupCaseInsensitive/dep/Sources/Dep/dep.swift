public struct dep {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
