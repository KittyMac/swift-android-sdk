public struct pkg {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
