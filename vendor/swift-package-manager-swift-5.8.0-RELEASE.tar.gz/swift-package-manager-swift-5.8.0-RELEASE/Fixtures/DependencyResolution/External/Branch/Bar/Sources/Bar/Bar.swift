import Foo

struct Bar {
    var text = "Hello, World!"
}
