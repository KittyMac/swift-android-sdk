struct Foo {
    var text = "Hello, World!"
}
