#include <Foo/Foo.h>

void cool() {
    foo();
}