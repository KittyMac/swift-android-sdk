void foo();
