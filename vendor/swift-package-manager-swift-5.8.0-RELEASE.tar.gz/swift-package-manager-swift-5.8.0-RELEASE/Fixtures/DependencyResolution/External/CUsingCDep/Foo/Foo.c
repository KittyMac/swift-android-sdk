void foo() {
    
}
