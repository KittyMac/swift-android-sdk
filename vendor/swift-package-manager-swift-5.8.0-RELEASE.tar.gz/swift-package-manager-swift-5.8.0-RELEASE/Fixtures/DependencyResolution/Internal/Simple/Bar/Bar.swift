public struct Bar {
    public init() {}
    public let value = "Bar"
}
