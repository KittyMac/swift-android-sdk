import Bar

print(Foo().value)
print(Bar().value)
