class Foo {
    let value = "Foo"
}
