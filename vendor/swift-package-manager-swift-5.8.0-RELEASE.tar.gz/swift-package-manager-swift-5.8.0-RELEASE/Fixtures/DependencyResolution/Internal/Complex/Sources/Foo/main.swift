print(foo())

// TODO copy this fixture and make one that should not compile due to the dependency not being specified
