public class Sound: CustomStringConvertible {
    public init()
    {}

    public var description: String {
        return "meiow"
    }
}
