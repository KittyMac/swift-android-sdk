public class Baz {
    public let value = "Baz"
    public init()
    {}
}
