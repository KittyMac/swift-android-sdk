import Baz
import Cat

public class Bar {
    public init()
    {}

    public let baz = Baz()
    public let cat = Cat()
}
