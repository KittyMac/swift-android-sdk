import Sound

public class Cat {
    public let sound = Sound()
    public init()
    {}
}
