public func funcC() {
    print("func C")
}
