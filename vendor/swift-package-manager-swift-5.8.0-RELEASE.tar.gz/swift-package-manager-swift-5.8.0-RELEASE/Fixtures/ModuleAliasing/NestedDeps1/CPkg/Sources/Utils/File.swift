public func utilsInC() {
    print("utils in C")
}
