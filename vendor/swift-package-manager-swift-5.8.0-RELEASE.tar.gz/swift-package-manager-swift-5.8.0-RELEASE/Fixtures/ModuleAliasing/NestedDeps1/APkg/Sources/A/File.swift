import FooUtils
import CarUtils

public func funcInA() {
    print("func in A")
    utilsInB()
    utilsInC()
}
