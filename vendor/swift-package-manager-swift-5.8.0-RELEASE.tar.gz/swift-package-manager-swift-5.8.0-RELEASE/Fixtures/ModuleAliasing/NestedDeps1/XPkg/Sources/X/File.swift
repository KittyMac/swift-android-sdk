import Utils
import FooUtils

public func funcInX() {
    print("func in X")
    utilsInX()
    utilsInY()
}
