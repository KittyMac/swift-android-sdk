int foo() {
    return 123;
}
