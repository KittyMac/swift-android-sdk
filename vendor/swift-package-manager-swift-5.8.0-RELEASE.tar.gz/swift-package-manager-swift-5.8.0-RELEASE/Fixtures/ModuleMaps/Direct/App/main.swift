import CFoo

print(foo())
